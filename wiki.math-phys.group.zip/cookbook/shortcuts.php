<?php if (!defined('PmWiki')) exit();
/*  Copyright 2007 Michael Shanley

	This file is ShortCuts.php; 
	you can redistribute it and/or modify it under the terms of the GNU 
	General Public License as published by the Free Software Foundation; 
	either version 2 of the License, or (at your option) any later 
	version.  

    1. To use this script, simply place it into the cookbook/ folder
       and add the line to config.php:
        
		include("$FarmD/cookbook/shortcuts.php");
		
	2. Then, make {$SiteGroup}/ShortCuts into a definition list like so:
	
		:c:[[mailto:who@this.place|contact me]]
		:m:[[Main/]]
		:shit:poop
		:inc:(:include Site.Sidebar:)
		:baby:http://www.thebabythatbecameinfinity.com
		
		etc...
		
	3. You can use your shortcuts on any page like this: 
	
		>m>

	Optionally, you can change ShortCuts looks for shortcuts,
	And you can even change how the ShortCut is defined:
	
		$ShortCutsPage = "Main/CustomCode";
		$ShortCutsPrefix = '--';
		$ShortCutsSuffix = 'ars';
		include_once("$FarmD/cookbook/shortcuts.php");
		
	Which would make the above ShortCut look like this:
	
		--mars
		
		;)
*/

# VERSION INFO
	$RecipeInfo['ShortCuts']['Version'] = '2007-08-31';

## VARIABLES
	SDV($ShortCutsPage,"{$SiteGroup}/ShortCuts"); //Where is your ShortCut list located?

	SDV($ShortCutsPrefix,'['); //What starts the ShortCut?  || almost anything is acceptable, 
	SDV($ShortCutsSuffix,']'); //What ends the ShortCut?    || except nothing '' or a space ' '.
	
	##For multiple instances, set this value before each subsequent INCLUDE:
	//$ShortCutsRedux = ?;

## CODE ##
	##Prepare Prefix and Suffix
	$ShortCutsPrefix = preg_quote(htmlentities($ShortCutsPrefix),'/');
	$ShortCutsSuffix = preg_quote(htmlentities($ShortCutsSuffix),'/');

	Markup('SHORTCUTS'.$ShortCutsRedux,'<{$var}',
		'/'.$ShortCutsPrefix.'([0-9a-zA-Z]+?)'.$ShortCutsSuffix.'/',
		'{'.$ShortCutsPage.'$:$1}');