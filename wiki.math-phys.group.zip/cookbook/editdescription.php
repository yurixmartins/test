<?php if (!defined('PmWiki')) exit();
/*
  EditTitle (v 1.1)
  
  Copyright 2005 - Waylan Limberg (waylan@gmail.com)
  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published
  by the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  Description: Adds a Title input field to the edit form of PmWiki.
  For more info and instructions go to http://www.pmwiki.org/wiki/Cookbook/EditTitle
*/



## define default variables 
if (!isset($EditDescriptionInputFmt))
  $EditDescriptionInputFmt = "<label><input type='text' \$InputFormArgs /></label>";
if (!isset($ForceDescriptionMessageFmt))
  $ForceDescriptionMessageFmt = '<p style="color:red">An abstract must be defined for this page.</p>';
# pattern should be same as defined in markup
if (!isset($EditDescriptionPattern))
  $EditDescriptionPattern = '/\\(:Description\\s(.*?):\\)/i';

## define pointers to functions (Note: order IS important)
array_push($EditFunctions, 'RemoveDescription');
array_unshift($EditFunctions, 'RequireDescription');
array_unshift($EditFunctions, 'AddDescription');
array_unshift($EditFields, 'description');

## RemoveTitle removes title from markup and  sets it to display in text input field
function RemoveDescription($pagename, &$page, &$new){
  global $InputTags, $EditDescription, $EditDescriptionInputFmt, $EditDescriptionPattern;
  if (isEnabled($EditDescription, 1)) {
    if (!isset($new['description'])){
      if (preg_match($EditDescriptionPattern, $new['text'], $matches)){
        $new['description'] = $matches[1];
      }else{
        $new['description'] = '';
      }
    }
    $new['text'] = trim(preg_replace($EditDescriptionPattern,'', $new['text'] ));    
    SDVA($InputTags["e_description"], array(
      ':html' => $EditDescriptionInputFmt, 'name' => 'description', 
      'size' => '90' , 'height' => '10', 'value' => $new['description']));
  } else {
    SDVA($InputTags["e_description"], array(':html' => ''));
  }
  return;
}

## AddTitle adds title back into markup before saving
function AddDescription($pagename, &$page, &$new){
  global $EditDescription;
  if ($new['description'] > '' && isEnabled($EditDescription, 1)) 
    $new['text'] = "(:Description ".$new['description'].":)\n".$new['text'];
  return;
}

## Require that a title be defined on each page
function RequireDescription($pagename, &$page, &$new){
  global $EnablePost, $MessagesFmt, $ForceDescription, $DeleteKeyPattern,
    $EditDescriptionPattern, $ForceDescriptionMessageFmt;
  if (isEnabled($ForceDescription, 0) && (trim($new['text']) != $DeleteKeyPattern) &&
     (!preg_match($EditDescriptionPattern, $new['text']))) {
      $EnablePost = 0;
      $MessagesFmt[] = $ForceDescriptionMessageFmt;
  }
  return;
}