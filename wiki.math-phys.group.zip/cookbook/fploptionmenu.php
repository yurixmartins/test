<?php if (!defined('PmWiki')) exit();
/*
 * OptionMenu - A form option menu format for the (:pagelist:) and
 * (:searchresults:) directives.
 * Copyright 2006-2010 by D.Faure (dfaure@cpan.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * See http://www.pmwiki.org/wiki/Cookbook/OptionMenu for info.
 */
$RecipeInfo['OptionMenu']['Version'] = '2010-02-18';

$FPLFunctions['optionmenu'] = 'FPLOptionMenu';

function FPLOptionMenu($pagename, &$matches, $opt) {
  global $FPLOptionMenuOpt, $HTMLHeaderFmt, $EnableFPLOptionMenuJS, $ScriptUrl,
   $EnablePathInfo, $FPLOptionMenuFmt;
  SDVA($FPLOptionMenuOpt, array('size' => '1', 
    'form'     => 'optionmenu',
    'selclass' => 'inputbox',
  ));
  $opt = array_merge((array)$FPLOptionMenuOpt, (array)$opt);
  if(IsEnabled($EnableFPLOptionMenuJS, 1) && !$HTMLHeaderFmt['optionmenu'])
    $HTMLHeaderFmt['optionmenu'] = "<script type='text/javascript'><!--
function handleOptionMenu(menu, script_url, path_info) {
  location.href = script_url + (path_info ?
  ('/' + menu.options[menu.selectedIndex].value.replace('.', '/')) :
  ('?n=' + menu.options[menu.selectedIndex].value));
} //--></script>\n";
  ##  get the list of pages
  $matches = array_values(MakePageList($pagename, $opt, 0));
  ##  extract page subset according to 'count=' parameter
  if (@$opt['count']) {
    list($r0, $r1) = CalcRange($opt['count'], count($matches));
    if ($r1 < $r0) 
      $matches = array_reverse(array_slice($matches, $r1-1, $r0-$r1+1));
    else 
      $matches = array_slice($matches, $r0-1, $r1-$r0+1);
  }
  $out = array();
  $out[] = "<form name='{Tags}' method='get' action='' class='fploptionmenu'>\n";
  $out[] = " <select class='{$opt['selclass']}' size='{$opt['size']}' name='Tags'";
  if(IsEnabled($EnableFPLOptionMenuJS, 1)) {
    $out[] = ")'";
  }
  $out[] =   ">\n";
  SDV($FPLOptionMenuFmt, "\$Titlespaced");
  foreach($matches as $item) {
    $out[] = "  <option ";
    if($pagename == $item) $out[] = "selected=Quantum";
    $out[] = FmtPageName("value='$item'>$FPLOptionMenuFmt</option>\n", $item);
  }
  $out[] = " </select>\n";

  return implode('', $out);
}
