<?php /*>*/ if (!defined('PmWiki')) exit();
/* CodeMirror - An enhanced page editor for PmWiki
 * Copyright (C) 2013-2019 by D.Faure <dominique.faure@gmail.com>,
 * Simon Davis <nzskiwi@gmail.com> and Marijn Haverbeke <marijnh@gmail.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 * See http://www.pmwiki.org/wiki/Cookbook/CodeMirror for more info.
 */
$RecipeInfo['CodeMirror']['Version'] = '2021-04-08';

### Base configuration
SDV($CodeMirrorBaseUrl, "$PubDirUrl/codemirror-5.60.0");
SDV($CodeMirrorDirUrl,  "$PubDirUrl/cm");
SDV($CodeMirrorScriptName, 'codemirror.js');
SDV($CodeMirrorConfig, array());
SDV($CodeMirrorScriptTrailer, array());
SDV($CodeMirrorAddonsFmt, array());
SDV($CodeMirrorStylesFmt, array());
SDVA($HTMLHeaderFmt, array('codemirror' => array(
  "\n<script type='text/javascript' src='$CodeMirrorBaseUrl/lib/$CodeMirrorScriptName'></script>\n",
  "<link rel='stylesheet' type='text/css' href='$CodeMirrorBaseUrl/lib/codemirror.css' />\n",
  &$CodeMirrorAddonsFmt,
#  "<link rel='stylesheet' type='text/css' href='$CodeMirrorBaseUrl/doc/doc.css' />\n",
  "<style type='text/css'><!--\n",
    &$CodeMirrorStylesFmt,
  "\n--></style>\n"
)));

### Source Block Stuff
if (IsEnabled($EnableCodeMirrorBlockMarkup, 1))
  include_once("cookbook/cm-sourceblock.php");

### Page Editing Stuff
if ($action != 'edit' || !IsEnabled($EnableCodeMirrorPageEditing, 1)) return;

SDVA($InputTags['e_textarea'], array(
  'id' => 'text',
  ':fn' => 'InputCodeMirrorMarkup',
  ':html' => "<div id='cm-container'><textarea \$InputFormArgs>\$EditText</textarea><div id='cm-resizer'></div></div>"));

function InputCodeMirrorMarkup($pagename, $type, $args) {
  global $CodeMirrorBaseUrl, $CodeMirrorScript, $CodeMirrorConfig, $CodeMirrorScriptTrailer;
  SDV($CodeMirrorScript, "<script type='text/javascript'>
function toggleCodeMirror() {
  var pagename = '$pagename',
      tarea = document.getElementById('text');
  if (typeof CodeMirror === 'undefined') {
    alert('?CodeMirror distribution not found. Check base url (\$CodeMirrorBaseUrl).');
    return tarea;
  }

  if (tarea.codemirror) {
    tarea.codemirror.toTextArea();
    delete tarea.codemirror;
  } else {
    tarea.codemirror = CodeMirror.fromTextArea(tarea, { \$CodeMirrorConfig });
  }

  \$CodeMirrorScriptTrailer

  return tarea;
}
toggleCodeMirror();
</script>\n");
  $cfg = implode(", ", $CodeMirrorConfig);
  $trail = implode("\n", $CodeMirrorScriptTrailer);
  $opt = NULL;
  return Keep(InputToHTML($pagename, $type, $args, $opt) .
              str_replace(array('$pagename', '$CodeMirrorBaseUrl', '$CodeMirrorConfig', '$CodeMirrorScriptTrailer'),
                          array($pagename, $CodeMirrorBaseUrl, $cfg, $trail),
                          $CodeMirrorScript));
}

if (IsEnabled($EnableGUIButtons, 1)) {
  SDVA($HTMLHeaderFmt, array('guiedit' => "<script type='text/javascript' src='$CodeMirrorDirUrl/cmguiedit.js'></script>\n"));
  SDV($GUIButtons['cm'], array(9999, '', '', '',
    "<label class='cm_check' for='cm_check'><input id='cm_check' type='checkbox' checked='unchecked' onclick='toggleCodeMirror()' />Highlight</label>", ''));
    SDV($GUIButtons['upload'], array(220, '', '', '',
    "<a href='\$PageUrl?action=upload' target='_blank'><img src='https://wiki.math-phys.group/pub/guiedit/attach.gif' alt='Upload a file'></a>", ''));
  SDV($CodeMirrorStylesFmt['buttons'], "
.cm_check { vertical-align: top; }
");
}

SDVA($CodeMirrorPresetParams, array(
  'maxheight' => 'auto',
  'placeholder' => 'Enter your code here...',
  'match-highlighter' => '/\w/',
));
SDVA($CodeMirrorPresets, array(
  'default' => array(
    'style' => "
.CodeMirror {
  border-top: 1px solid #ddd;
  border-bottom: 1px solid #ddd;
}
"),

  'syntax' => array(
    'config' => "mode: 'pmwiki'",
    'addon' => "
<script type='text/javascript' src='$CodeMirrorDirUrl/pmwiki.js'></script>
<link rel='stylesheet' type='text/css' href='$CodeMirrorDirUrl/pmwiki.css' />
"),

  'selection' => array(
    'config' => "styleSelectedText: true",
    'addon' => "<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/selection/mark-selection.js'></script>",
    'style' => "
.CodeMirror-selected  { background-color: darkblue !important; }
.CodeMirror-selectedtext { color: white; }
"),

  'cursor' => array(
    'style' => "
.CodeMirror div.CodeMirror-cursor {  border-left: 2px solid darkblue; }
.CodeMirror div.CodeMirror-overwrite div.CodeMirror-cursor { border-left: 2px solid red; }
"),

  'linenumbers' => array(
   'config' => "lineNumbers: true",
),

  'linewrapping' => array(
    'config' => "lineWrapping: true",
),

  'activeline' => array(
    'config' => "styleActiveLine: true",
    'addon' => "<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/selection/active-line.js'></script>",
    'style' => "
.CodeMirror div.CodeMirror-activeline-background { background-color: #fafafa; }
"),

  'visualtab' => array(
    'style' => "
.cm-tab {
  background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAMCAYAAAAkuj5RAAAAAXNSR0IArs4c6QAAAGFJREFUSMft1LsRQFAQheHPowAKoACx3IgEKtaEHujDjORSgWTH/ZOdnZOcM/sgk/kFFWY0qV8foQwS4MKBCS3qR6ixBJvElOobYAtivseIE120FaowJPN75GMu8j/LfMwNjh4HUpwg4LUAAAAASUVORK5CYII=);
  background-position: right;
  background-repeat: no-repeat;
}"),

  'trailingspace' => array(
    'config' => "showTrailingSpace: true",
    'addon' => "<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/edit/trailingspace.js'></script>",
    'style' => "
.cm-trailingspace {
  background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAACCAYAAAB/qH1jAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH3QUXCToH00Y1UgAAACFJREFUCNdjPMDBUc/AwNDAAAFMTAwMDA0OP34wQgX/AQBYgwYEx4f9lQAAAABJRU5ErkJggg==);
  background-position: bottom left;
  background-repeat: repeat-x;
}"),

  'tabfocus' => array(
    'keys' => array('Tab' => "false", 'Shift-Tab' => "false"),
  ),

  'continuelist' => array(
    'keys' => array('Enter' => "'newlineAndIndentContinuePmWikiList'"),
    'addon' => "<script type='text/javascript' src='$CodeMirrorDirUrl/cmcontinuelist.js'></script>",
  ),

  'autoresize' => array(
    'config' => "viewportMargin: Infinity",
    'style' => "
.CodeMirror {
  border-right: 0px solid #ddd;
  max-height: 80%;
}
.CodeMirror-scroll {
  overflow-y: hidden;
  overflow-x: auto;
}"),

  'maxheight' => array(
    'style' => "
.CodeMirror {
  border-right: 1px solid #ddd;
  height: auto;
  max-height: $CodeMirrorPresetParams[maxheight];
}
.CodeMirror-scroll {
  overflow-x: auto;
  max-height: $CodeMirrorPresetParams[maxheight];
}"),

  'resizer' => array(
    'addon' => "<script type='text/javascript' src='$CodeMirrorDirUrl/cmresizer.js'></script>",
    'trail' => "setupCodeMirrorResizer(document.getElementById('cm-container'), tarea, document.getElementById('cm-resizer'));",
    'style' => "
#cm-container { position: relative; }
#cm-container textarea {
  resize: none;
}
#cm-resizer {
	position: absolute;
	bottom: -0.5em;
	height: 0.5em;
	width: 100%;
	background-color: #ddd;
	cursor: ns-resize;
}",
  ),

  'posfix' => array(
    'addon' => "<script type='text/javascript' src='$CodeMirrorDirUrl/cmposfix.js'></script>",
    'trail' => "setupCodeMirrorPosFix(pagename, tarea);",
  ),

  'annotate-scrollbars' => array(
    'addon' => "
<link rel='stylesheet' type='text/css' href='$CodeMirrorBaseUrl/addon/search/matchesonscrollbar.css' />
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/scroll/annotatescrollbar.js'></script>
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/search/matchesonscrollbar.js'></script>
",
    'style' => "
.CodeMirror-selection-highlight-scrollbar { background-color: rgba(255, 255, 0, 0.4); }
",
  ),

  'search' => array(
    'keys' => array('Alt-F' => "'findPersistent'"),
    'addon' => "
<link rel='stylesheet' type='text/css' href='$CodeMirrorBaseUrl/addon/dialog/dialog.css' />
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/dialog/dialog.js'></script>
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/search/search.js'></script>
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/search/searchcursor.js'></script>
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/search/jump-to-line.js'></script>
"),

  'match-highlighter' => array(
    'config' => "highlightSelectionMatches: { showToken: ".$CodeMirrorPresetParams['match-highlighter'].", annotateScrollbar: true }",
    'addon' => "
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/search/searchcursor.js'></script>
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/search/match-highlighter.js'></script>
",
    'style' => "
.CodeMirror-focused .cm-matchhighlight {
  background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAYAAABytg0kAAAAFklEQVQI12NgYGBgkKzc8x9CMDAwAAAmhwSbidEoSQAAAABJRU5ErkJggg==);
  background-position: bottom;
  background-repeat: repeat-x;
}
.cm-matchhighlight { background-color: rgba(255, 255, 0, 0.4); }
"),

  'hint' => array(
    'keys' => array('Ctrl-Space' => "'autocomplete'"),
    'addon' => "
<link rel='stylesheet' type='text/css' href='$CodeMirrorBaseUrl/addon/hint/show-hint.css'>
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/hint/show-hint.js'></script>
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/hint/anyword-hint.js'></script>
<script type='text/javascript'>
  CodeMirror.commands.autocomplete = function(cm) {
    cm.showHint({hint: CodeMirror.hint.anyword});
  }
</script>"),

  'fullscreen' => array(
    'keys' => array(
      'F11' => "function(cm) { cm.setOption('fullScreen', !cm.getOption('fullScreen')); }",
    ),
    'addon' => "
<link rel='stylesheet' type='text/css' href='$CodeMirrorBaseUrl/addon/display/fullscreen.css'>
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/display/fullscreen.js'></script>
",
    'style' => "
.CodeMirror.CodeMirror-fullscreen { max-height: none; }
.CodeMirror.CodeMirror-fullscreen .CodeMirror-scroll { max-height: none; }
"),
  'fullscreen-esc' => array(
    'keys' => array(
      'Esc' => "function(cm) { if (cm.getOption('fullScreen')) cm.setOption('fullScreen', false); }",
    ),
),

  'placeholder' => array(
    'config' => "placeholder: '$CodeMirrorPresetParams[placeholder]'",
    'addon' => "
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/display/placeholder.js'></script>
",
    'style' => "
.CodeMirror pre.CodeMirror-placeholder { color: #999; }"),
  'fold' => array(
    'config' => "foldGutter: true, gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter']",
    'keys' => array(
      'Ctrl-Q' => "function(cm) { cm.foldCode(cm.getCursor()); }",
    ),
    'addon' => "
<link rel='stylesheet' type='text/css' href='$CodeMirrorBaseUrl/addon/fold/foldgutter.css' />
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/fold/foldcode.js'></script>
<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/fold/foldgutter.js'></script>
<script type='text/javascript' src='$CodeMirrorDirUrl/cmfold.js'></script>
"),

  'emacs' => array(
    'config' => "keyMap: 'emacs'",
    'addon' => "
<script type='text/javascript' src='$CodeMirrorBaseUrl/keymap/emacs.js'></script>
"),

  'sublime' => array(
    'config' => "keyMap: 'sublime'",
    'addon' => "
<script type='text/javascript' src='$CodeMirrorBaseUrl/keymap/sublime.js'></script>
"),

  'vim' => array(
    'config' => "keyMap: 'vim'",
    'addon' => "
<script type='text/javascript' src='$CodeMirrorBaseUrl/keymap/vim.js'></script>
"),

));

SDVA($CodeMirrorActivePresets, array(
  'default' => 1,
  'syntax' => 1,
  'selection' => 1,
  'cursor' => 1,
  'linenumbers' => 1,
  'linewrapping' => 1,
  'activeline' => 1,
  'visualtab' => 1,
  'tabfocus' => 1,
  'continuelist' => 1,
  'placeholder' => 1,
));

function ActivateCodeMirrorPresets() {
  global $CodeMirrorPresets, $CodeMirrorActivePresets,
         $CodeMirrorConfig, $CodeMirrorScriptTrailer, $CodeMirrorAddonsFmt, $CodeMirrorStylesFmt;
  $extraKeys = array();
  foreach ($CodeMirrorActivePresets as $name => $enabled) {
    if (isset($CodeMirrorPresets[$name]) && $enabled) {
      $n = 'cm-' . $name;
      if (isset($CodeMirrorPresets[$name]['keys'])) {
        foreach($CodeMirrorPresets[$name]['keys'] as $k => $f)
          $extraKeys[] = "'$k': $f";
      }
      if (isset($CodeMirrorPresets[$name]['config']))
        $CodeMirrorConfig[$n] = $CodeMirrorPresets[$name]['config'];
      if (isset($CodeMirrorPresets[$name]['trail']))
        $CodeMirrorScriptTrailer[$n] = $CodeMirrorPresets[$name]['trail'];
      if (isset($CodeMirrorPresets[$name]['addon']))
        $CodeMirrorAddonsFmt[$n] = $CodeMirrorPresets[$name]['addon'];
      if (isset($CodeMirrorPresets[$name]['style']))
        $CodeMirrorStylesFmt[$n] = $CodeMirrorPresets[$name]['style'];
    }
  }
  if (count($extraKeys))
    $CodeMirrorConfig['cm-extrakeys'] = "extraKeys: { " . implode(', ', $extraKeys) . " }";
}

ActivateCodeMirrorPresets();
