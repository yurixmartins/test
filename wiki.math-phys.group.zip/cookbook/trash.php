<?php if (!defined('PmWiki')) exit();

/*  Copyright 2008 Christophe David (www.christophedavid.org)
    This file is trash.php. You can redistribute it and/or modify
    it under the terms of the GNU General Public License as published
    by the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This script makes it easy to "safely delete" pages and recover them.
    
    It adds two actions: 'trash' and 'untrash'.
    
    MyGroup.MyPage?action=trash
       will "rename" MyGroup.MyPage to MyGroup.MyPage-trashed

    MyGroup.MyPage-trashed?action=untrash
       will "rename" MyGroup.MyPage-untrash to MyGroup.MyPage

    Pagelists can be used to view the pages that are trashed, and to
    present links to untrash them.
    
       (:pagelist name=*-trashed:)

    By default, the user is redirected to the (un)trashed page.
    Optionally, the redirect parameter can be used to specify another page:
    
       MyGroup.MyPage?action=trash&redirect=Main.HomePage

    To use this script, simply copy it into the cookbook/ directory
    and add the following line to config.php or a per-page/per-group
    customization file.

        include_once('cookbook/trash.php');
*/

################################################################################

$RecipeInfo['Trash']['Version'] = '2008-12-18';

################################################################################

SDV($TrashedExtension, '-trashed');

if (preg_match('/' . $TrashedExtension . '$/', FmtPageName('$FullName', $pagename)) == 1)
   {
   $HandleActions['untrash'] = 'HandleUntrash';
   }
else
   {
   $HandleActions['trash']   = 'HandleTrash';
   }

################################################################################

function HandleTrash()
   {
   global $pagename, $WikiDir, $TrashedExtension;
   
   $page = RetrieveAuthPage($pagename,
                            'edit'
                            );
   if ($page)
      {
      Lock(2);

      $TrashedPagename = MakePageName($pagename,
                                      FmtPageName('$FullName', $pagename) . $TrashedExtension
                                     );

      UpdatePage(MakePageName($pagename,
                              $TrashedPagename
                             ),
                 $page,
                 $page
                );

      $WikiDir->delete($pagename);

      if ($_GET["redirect"] == '')
         {
         Redirect($TrashedPagename);
         }
      else
         {
         Redirect($_GET["redirect"]);
         }
      }

   exit;
   }

################################################################################

function HandleUntrash()
   {
   global $pagename, $WikiDir, $TrashedExtension;
   
   $page = RetrieveAuthPage($pagename,
                            'edit'
                            );
   if ($page)
      {
      Lock(2);

      $OriginalPagename = MakePageName($pagename,
                                       preg_replace('/' . $TrashedExtension . '$/',
                                                    '',
                                                    FmtPageName('$FullName', $pagename)
                                                   )
                                      );

      UpdatePage(MakePageName($pagename,
                              $OriginalPagename
                             ),
                 $page,
                 $page
                );

      $WikiDir->delete($pagename);

      if ($_GET["redirect"] == '')
         {
         Redirect($OriginalPagename);
         }
      else
         {
         Redirect($_GET["redirect"]);
         }
      }

   exit;
   }

################################################################################

?>
