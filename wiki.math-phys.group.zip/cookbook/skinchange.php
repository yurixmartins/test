<?php if (!defined('PmWiki')) exit;
/*  Copyright 2004, 2007, 2011 Patrick R. Michaud (pmichaud@pobox.com)

    This script enables the ?skin= and ?setskin= parameters for
    wiki pages.  The ?skin= parameter causes the current page to be 
    displayed with some alternate skin (defined by the WikiAdministrator),
    the ?setskin= parameter sets a cookie on the user's browser to
    always display pages with the requested skin.  

    The easy way to use this script is to do following in 
    local/config.php: 

        $EnableAutoSkinList = 1;
        include_once('cookbook/skinchange.php');

    This will allow browser to choose any skin that exists
    in the pub/skins/ or $FarmD/pub/skins/ directory.

    To only allow a specific set of skins, create an array
    called $PageSkinList that maps names from ?skin= or
    ?setskin= into the corresponding skin to be used for that
    name.  For example:
    
        $PageSkinList = array(
           'pmwiki' => 'pmwiki',
           'myskin' => 'myskin',
           'classic' => 'myclassicskin');
        include_once('cookbook/skinchange.php');

    If $EnableAutoSkinList is also set, then entries in
    $PageSkinList take precedence.  If a browser requests
    a skin that isn't available, then PmWiki defaults to
    the skin already defined by $Skin.

    By default, the setskin cookie that is created will expire after
    one year.  You can set it to expire at the end of the browser
    session by setting $SkinCookieExpires=0;
    
    Script maintained by Petko Yotov www.pmwiki.org/petko
*/

$RecipeInfo['SkinChange']['Version'] = '20171115';

SDV($SkinCookie, $CookiePrefix.'setskin');
SDV($SkinCookieExpires, $Now+60*60*24*365);

if (! function_exists('pmsetcookie')) {
  function pmsetcookie($name, $val="", $exp=0, $path="", $dom="", $secure=null, $httponly=null) {
    return setcookie($name, $val, $exp, $path, $dom, $secure, $httponly);
  }
}

if (isset($_COOKIE[$SkinCookie])) $sk = $_COOKIE[$SkinCookie];
if (isset($_GET['setskin'])) {
  $sk = $_GET['setskin'];
  pmsetcookie($SkinCookie, $sk, $SkinCookieExpires, '/');
  if(@$EnableIMSCaching) {
    SDV($IMSCookie, $CookiePrefix.'imstime');
    pmsetcookie($IMSCookie, '', $Now -3600, '/');
    $EnableIMSCaching = 0;
  }
}
if (isset($_GET['skin'])) $sk = $_GET['skin'];

##  If $EnableAutoSkinList is set, then we accept any skin that
##  exists in pub/skins/ or $FarmD/pub/skins/ .
if (IsEnabled($EnableAutoSkinList, 0) 
    && preg_match('/^[-\\w]+$/', $sk)
    && (is_dir("pub/skins/$sk") || is_dir("pub/skins/$sk")))
  $Skin = $sk;
  
if ($sk == 'presentation') include_once('cookbook/slides.php');  

##  If there's a specific mapping in $PageSkinList, we use it no
##  matter what.
if (@$PageSkinList[$sk]) $Skin = $PageSkinList[$sk];


