<?php if (!defined('PmWiki')) exit();

/*
  Copyright 2004-2015 Patrick R. Michaud (pmichaud@pobox.com)
  This file is jumpbox.php; you can redistribute it and/or modify
  it under the terms of the GNU General Public License version 2 
  as published by the Free Software Foundation.
  
  Contributions to this recipe were made by Dominique Faure
  
  Version 2015-10-02 - converted to work with PHP 5.5 
*/

$FmtPV['$_UniqId_'] = '($GLOBALS["_UniqId_"] = uniqid("id"))';
$FmtPV['$_PrevId_'] = '$GLOBALS["_UniqId_"]';
$InputTags['jumpbox'] = array(
  'name' => 'n',
  ':html' =>
    "<form action='none' method='get'>
     <select 
       \$InputSelectArgs class='inputbox' >\$InputSelectOptions</select>
     </form>");

Markup_e('input-jumpbox', '<split',
  '/\\(:input\\s+jumpbox\\s.*?:\\)(?:\\s*\\(:input\\s+jumpbox\\s.*?:\\))*/i',
  "InputSelect(\$pagename, 'jumpbox', \$m[0])");