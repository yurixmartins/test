<?php if (!defined('PmWiki')) exit();
##
##  ViewDiff was first written by Daniel Roesler (diafygi)
##  in April 2009. It is released under the Gnu Public
##  License version 2. Enjoy!
##  <http://www.gnu.org/licenses/gpl-2.0.txt>
##  
##  Contact:
##  <http://pmwiki.org/wiki/Cookbook/ViewDiff>
##  diafygi (curvy thing) gmail (period) com
##  <http://daylightpirates.org/>
##
##  Description:
##  ViewDiff is an action that creates a rendering of a page that
##  based on a certain time in its history. It will also display
##  the changes made to a page based on a second time.
##
##  Use:
##  To use ViewDiff, simply call the action 'viewdiff' in your
##  page url. This will display a temporary rendering of the
##  current page at the current time.
##  (http://example.com/wiki/Main/Home?action=viewdiff)
##  You can also specify a time by including its unix timestamp
##  in the url.
##  (http://example.com/wiki/Main/Home?action=viewdiff&time=1122334455)
##  You can compare two edits by including two times in the url
##  separated by a colon.
##  (http://example.com/wiki/Main/Home?action=viewdiff&time=1122334455:2233445566)
##  This action also accepts PmWiki formated Edit IDs
##  (http://example.com/wiki/Main/Home?action=viewdiff&time=diff:1122334455:2233445566:minor)
##  You can also separate the two times into two url variables
##  (http://example.com/wiki/Main/Home?action=viewdiff&time1=1122334455&time2=2233445566)
##  or, with PmWiki Edit IDs
##  (http://example.com/wiki/Main/Home?action=viewdiff&time1=diff:1122334455:2233445566:minor&time2=diff:3344556677:4455667788:minor)
##     (This will take the times 1122334455 and 3344556677)
##

# Create action and Version id (for RecipeCheck)
SDV($HandleActions['viewdiff'], 'ViewDiff');
$RecipeInfo['ViewDiff']['Version'] = '2011-05-13';

#Add custom formats for History page (?action=diff)
SDV($ViewDiffCompare, 1);
if($ViewDiffCompare) {
    SDV($DiffStartFmt, "  <div class='diffbox'><div class='difftime'>
	  <div class='diffradio'><input type='radio' id='time1:\$DiffId' name='time2' value='\$DiffId' onclick=\"hideradios()\" />&nbsp;</div>
      <div class='diffradio'><input type='radio' id='time2:\$DiffId' name='time1' value='\$DiffId' onclick=\"hideradios()\" />&nbsp;</div>
	  <a name='diff\$DiffGMT' href='#diff\$DiffGMT'>\$DiffTime</a>
      \$[by] <span class='diffauthor' title='\$DiffHost'>\$DiffAuthor</span> - \$DiffChangeSum</div>");
    SDV($PageDiffFmt, "<h2 class='wikiaction'>$[{\$FullName} History]</h2>
      <p>$DiffMinorFmt - $DiffSourceFmt</p>
      <form action='{\$PageUrl}' name='viewdiff' method='get'>
      <div class='diffradiotitle'>
        <input type='hidden' name='n' value='{\$FullName}' />
        <input type='hidden' name='action' value='viewdiff' />
        <div class='diffradiotext'><input type='submit' value='\$[Compare]' /></div>
      </div>");
    SDV($HTMLStylesFmt['viewdiff'], "
      .diffradiotitle { width:570px; height:1.1em; }
      .diffradiotext { float:right; }
      .diffradio { float:right; text-align:center; width:3em; }");
    SDV($HTMLHeaderFmt['viewdiff'], ($action=="diff") ? "
      <script type='text/javascript'>
        function hideradios() {
          var time1radios = document.viewdiff.time1;
          var time2radios = document.viewdiff.time2;
          var n = 0;
          var time1selected = 0;
          var time2selected = 0;
          for (n = 0; n < time1radios.length; n++) {
            if(time1radios[n].checked)
              time1selected = time1radios[n].id;
            if(time2radios[n].checked)
              time2selected = time2radios[n].id;
          }
          for (n = 0; n < time1radios.length; n++) {
            t1 = time1radios[n].id;
            t2 = time2radios[n].id;
            if(t1 < time1selected && t2 < time2selected) document.getElementById(t1).style.display = 'none';
            else document.getElementById(t1).style.display = 'inline';
            if(t1 > time1selected && t2 > time2selected) document.getElementById(t2).style.display = 'none';
            else document.getElementById(t2).style.display = 'inline';
          }
        }
      </script>
      " : '');
}

# Include pagerev.php to access RenderDiff function and
# default formatting variables
SDV($HandleActions['diff'], 'HandleDiffView');
include_once("$FarmD/scripts/pagerev.php");

# Added DiffFmtChanges() function to so formatting
# changes can be made before rendering the History
# page (?action=diff)
function HandleDiffView($pagename, $auth) {
  DiffFmtChanges();
  HandleDiff($pagename, $auth);
}

# Changes the formatting of the History page (?action=diff)
# to include a comparison form
function DiffFmtChanges() {
  global $action, $ViewDiffCompare, $HandleDiffFmt, $PageStartFmt,
    $PageDiffFmt, $PageEndFmt, $PageDiffFmt, $DiffMinorFmt,
    $DiffSourceFmt, $DiffStartFmt, $HTMLStylesFmt, $HTMLHeaderFmt;

  #Change formatting if comparison form should display
  if($ViewDiffCompare) {
    #Changed formatting variables in History page to include comparison form
    $HandleDiffFmt = array(&$PageStartFmt,
      &$PageDiffFmt,"<div id='wikidiff'>", 'function:PrintDiff', '</div></form>',
      &$PageEndFmt);
  }
}

# Create formatting defaults for ViewDiff action
SDV($ViewDiffTimeFmt, 'M d, Y, H:i.');
SDV($ViewDiffStartFmt, "<h2>Version of \$ViewDiffTime1 (<a href='https://wiki.math-phys.group/\$FullName?action=diff'>return</a>)</h2>\n");
SDV($ViewDiffChangesFmt, "\$ViewDiffChanges\n");
SDV($ViewDiffTextFmt, "<hr />\n<div id='viewdiff'>\$ViewDiffText</div>\n");

# This function runs when the viewdiff action is called.
# It takes one or two given times and displays the first
# while also showing the changes between the first and
# second.
function ViewDiff($pagename, $auth = 'read', $time = NULL) {
  global $action, $PageStartFmt, $PageDiffFmt, $ViewDiffTimeFmt,
    $ViewDiffStartFmt, $PageEndFmt, $FmtV, $DiffFunction,
    $ViewDiffTextFmt, $ViewDiffChangesFmt, $ViewDiffFmt,
	$DiffShow;
	
	
  
  #Get time from url
  if($_REQUEST['time']) $time = $_REQUEST['time'];
  if($_REQUEST['time1']) {
    $time = $_REQUEST['time1'];
    if($_REQUEST['time2'])
      $time .= ':'.$_REQUEST['time2'];
  }
  if(is_null($time)) $time = time();

  #Check to see if second time given
  $time = explode(":", $time);
  switch(count($time)) {
    case 1: $time[1] = $time[0]; break;
    case 2: break;
    case 4: array_shift($time); array_pop($time); break;
    case 8: $time = array($time[1], $time[5]); break;
    default: return;
  }

  #Reorder so most recent time is first
  if($time[0]<$time[1]) {
    $t = $time[0]; $time[0] = $time[1]; $time[1] = $t;
  }

  #Generate time for version
  $FmtV['$ViewDiffTime1'] = gmdate($ViewDiffTimeFmt, $time[0]);
  $FmtV['$ViewDiffTime2'] = gmdate($ViewDiffTimeFmt, $time[1]);

  #Get page (with edit history)
  $page = RetrieveAuthPage($pagename, $auth, true, 0);
  if (!$page) Abort("?cannot generate feed");

  #Restore page to first timestamp
  $t = 'diff:'.$time[0].':'.$time[0].':';
  $markup = RestorePage($pagename, $page, $new, $t);

  #Create diff if needed
  if($time[0] != $time[1]) {
    $t = 'diff:'.$time[1].':'.$time[1].':';
    $old = RestorePage($pagename, $page, $new, $t);
    $diff = $DiffFunction($markup, $old);
  }

  #Add text to format variables
  $FmtV['$ViewDiffText'] = MarkupToHtml($pagename, $markup);
  $FmtV['$ViewDiffChanges'] = DiffHTML($pagename, $diff);

  #Print page
  $VersionTextFmt = FmtPageName($ViewDiffTextFmt, $pagename);
  SDV($ViewDiffFmt, array(&$PageStartFmt, &$ViewDiffStartFmt,
    &$ViewDiffChangesFmt, &$ViewDiffTextFmt, &$PageEndFmt));
  PrintFmt($pagename, $ViewDiffFmt);
}
