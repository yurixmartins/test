<?php /*>*/ if (!defined('PmWiki')) exit();
/* CodeMirror - An enhanced page editor for PmWiki
 * Please refer to the main source module for copyright and license info.
 * Latest required version: 2021-04-08
 */
if (!isset($RecipeInfo['CodeMirror'])) Abort("?cm-sourceblock require CodeMirror");
if (!function_exists('json_decode'))  Abort("?cm-sourceblock require json_decode() function");

SDV($CodeMirrorModesDependenciesAction, "cm-dependencies");
SDV($CodeMirrorModesDependenciesFile, "$FarmD/cookbook/cm-modes-dependencies.php");
@include_once($CodeMirrorModesDependenciesFile);

function CodeMirrorHandleDependencies($pagename, $auth = 'admin') {
  global $FarmD, $CurrentTime, $CodeMirrorBaseUrl, $CodeMirrorModesDependenciesFile;

  $modedir = str_replace('$FarmPubDirUrl', "$FarmD/pub", $CodeMirrorBaseUrl) . '/mode';

  # get mode specifications from meta.js
  $meta = file_get_contents($modedir . '/meta.js');
  preg_match('/CodeMirror\.modeInfo\s+=\s+(\[.*?\])\s*;/s', $meta, $m);
  $json = preg_replace(array('/([{,]+\s*)([^"{]+?)\s*:/',        # quote identifiers
                             '/([\[:]\s*)\/.*?\/[ig]?([,}\]])/', # drop regexes
                             '/,\s*(?=])/',                      # drop extraneous trailing commas
                             ),
                       array('$1"$2":',
                             '$1""$2',
                             '',
                             ), $m[1]);
  $infos = json_decode($json, true);
  $modes = array();
  $specs = array();
  foreach ($infos as $i) {
    $modes[$i['mode']] = 1;
    if (isset($i['mimes']))
      foreach ($i['mimes'] as $m)
        $specs[$m] = $i['mode'];
    else
      $specs[$i['mime']] = $i['mode'];
  }

  # fetch individual modes dependencies according to meta.js
  function getDependencies(&$specs, $modedir, $modes) {
    $deps = array();
    foreach ($modes as $mode => $x) {
      $specs[$mode] = $mode;
      $fname = "$modedir/$mode/$mode.js";
      if (file_exists($fname)) {
        $code = file_get_contents($fname);
        preg_match_all("/define\\s*\\(\\s*\[\\s*([^\\]]+)\\s*\\]\\s*,/", $code, $m);
        $dep = preg_replace(array("/([\"']).*?codemirror\\1\\s*(,?)\\s*/", # self-declare
          "/([\"'])\\.\\.(.*?)\\1\\s*(,?)\\s*/",   # dependencies as script filenames
        ),
          array("/$mode/$mode.js$2",
            "$2.js$3",
          ), $m[1][0]);
        $deps[$mode] = array_reverse(explode(',', $dep));
      }
    }
    return $deps;
  }

  # resolve inter-related dependencies (1 level depth only)
  function resolveDependencies($deps)
  {
    $out = array();
    foreach ($deps as $mode => $sl) {
      $out_sl = array();
      foreach ($sl as $s) {
        if (preg_match("/\\/([^\\/]+)\\/\\1\\.js/", $s, $m) && $m[1] != $mode) {
          if (isset($deps[$m[1]])) {
            foreach ($deps[$m[1]] as $msl)
              $out_sl[] = $msl;
          }
        } else
          $out_sl[] = $s;
      }
      $out[$mode] = $out_sl;
    }
    return $out;
  }

  $deps = getDependencies($specs, $modedir, $modes);
  $deps = resolveDependencies($deps);
  ksort($deps);

  $out = "<?php /*>*/ if (!defined('PmWiki')) exit();\n# Codemirror mode dependencies auto-generated file\n# $CurrentTime\n\n"
      . "\$CodeMirrorModesReferenceUrl = '$CodeMirrorBaseUrl';\n"
      . 'SDVA($CodeMirrorModeSpecs, ' . var_export($specs, true) . ");\n"
      . 'SDVA($CodeMirrorModes,  ' . preg_replace(array("/(=>)\\s*\n/s", "/\\d+\\s*=>\\s*/"), array("$1", ""), var_export($deps, true)) . ");\n";

  if (($fp = @fopen($CodeMirrorModesDependenciesFile, "w"))) {
    fwrite($fp, $out);
    fclose($fp);
    Redirect($pagename);
    exit;
  }
  Abort("<pre>
# Unable to generate CodeMirror mode dependencies file ($CodeMirrorModesDependenciesFile).
# Configuration data given below:

# =====8<- - - - -
$out
# =====8<- - - - -
</pre>");
}

$HandleActions[$CodeMirrorModesDependenciesAction] = "CodeMirrorHandleDependencies";

Markup('cmblock', '>markupend',
  "/\\(:code(\\s+([^\n]*?))?\\s*:\)[^\\S\n]*\\[([=@])(.*?)\\3\\]/si",
  "CodeMirrorBlockMarkup");
Markup('cmblockend', '>cmblock',
  "/\\(:(code)(\\s+([^\n]*?))?\\s*:\)[^\\S\n]*\n(.*?)\\(:codee?nd:\\)/si",
  "CodeMirrorBlockMarkup");
function CodeMirrorBlockMarkup($m) {
  extract($GLOBALS['MarkupToHTML']);
  return Keep(CodeMirrorBlock($pagename, $m[2], $m[4]));
}

function CodeMirrorBlock($pagename, $args, $block) {
  global $CodeMirrorBaseUrl, $CodeMirrorDirUrl, $CodeMirrorAddonsFmt, $CodeMirrorStylesFmt,
         $CodeMirrorBlockParams, $CodeMirrorBlockFmt, $CodeMirrorModeListFmt, $CodeMirrorModesMissingFmt,
         $CodeMirrorModesReferenceUrl, $CodeMirrorModeSpecs, $CodeMirrorModes,
         $CodeMirrorModesDependenciesAction;

  SDVA($CodeMirrorAddonsFmt, array(
    'sourceblock' => "\n<script type='text/javascript' src='$CodeMirrorBaseUrl/addon/runmode/runmode.js'></script>\n"
                   . "<script type='text/javascript' src='$CodeMirrorDirUrl/cmblock.js'></script>\n",
  ));
  SDV($CodeMirrorBlockFmt, "
<div class='cmblocktext \$class' \$id>
  <textarea id='cm_i\$cm_id' style='display:none;'>\$txt</textarea>
  <script>cmblock('cm_i\$cm_id', 'cm_o\$cm_id',  '\$modeSpec', { \$opts }, \$olOffset, [\$olHighlight]);</script>
</div>
");
  SDV($CodeMirrorStylesFmt['codemirrorblock'], "
.cmblocktext {
  border-left: 2px solid #ddd;
  padding-left: 15px;
}
.cmblocktext .CodeMirror-linenumber{
  text-align: left;
  margin: 0;
}
.cmblocktext .CodeMirror-highlight, .cmblocktext .CodeMirror-highlight pre {
  background-color: #fcfc96;
}
.cmblocktext pre {
  border: none;
  background-color: white;
  padding: 0;
  margin: 0;

  white-space: pre-wrap;      /* CSS 3 */
  white-space: -moz-pre-wrap; /* Mozilla, since 1999 */
  white-space: -pre-wrap;     /* Opera 4-6 */
  white-space: -o-pre-wrap;   /* Opera 7 */
  word-wrap: break-word;      /* Internet Explorer 5.5+ */
}
");

  $opt = array_merge((array)$CodeMirrorBlockParams, ParseArgs($args));
  if (@in_array('modelist', $opt[''])) {
    SDV($CodeMirrorAddonsFmt['modelist'], "<script type='text/javascript' src='$CodeMirrorBaseUrl/mode/meta.js'></script>\n");
    SDV($CodeMirrorModeListFmt, "
<div id='cm_i\$cm_id'>
  <script>cmmodelist('cm_i\$cm_id', { \$opts });</script>
</div>
");
    $CodeMirrorBlockFmt = $CodeMirrorModeListFmt;
    $mode = $opts = $block = '';
    $olOffset = null;
  } else {
    $modeSpec = IsEnabled($opt[''][0], "");
    if ($modeSpec) {
      if (isset($CodeMirrorModesReferenceUrl) && $CodeMirrorModesReferenceUrl == $CodeMirrorBaseUrl) {
        $mode = @$CodeMirrorModeSpecs[$modeSpec];
        if(@$CodeMirrorModes[$mode])
          SDV($CodeMirrorAddonsFmt[$mode],
            "<script type='text/javascript' src='$CodeMirrorBaseUrl/mode"
            . implode("'></script>\n<script type='text/javascript' src='$CodeMirrorBaseUrl/mode", $CodeMirrorModes[$mode])
            . "'></script>");
      } else {
        $url = PageVar($pagename, '$PageUrl');
        SDV($CodeMirrorModesMissingFmt, "<div><pre>!!! The CodeMirror mode dependencies file is outdated or missing !!! <a href='$url?action=$CodeMirrorModesDependenciesAction'>generate it</a></pre></div>");
        $CodeMirrorBlockFmt = $CodeMirrorModesMissingFmt;
        $modeSpec = $opts = $block = '';
        $olOffset = null;
      }
    }
    SDV($opts, '');
    $olOffset = @in_array('linenum', $opt['']) ? 1 :
            (isset($opt['linenum']) ? (0 + $opt['linenum']) : null);
    $olHighlight = isset($opt['highlight']) ? $opt['highlight'] : '';
    # undo PmWiki's htmlspecialchars conversion
    $block = str_replace(array('<:vspace>', '&lt;', '&gt;', '&amp;'),
                         array('', '<', '>', '&'), $block);
  }
  $id = (@$opt['id']) ? "id='{$opt[id]}'" : "";
  $cm_id = uniqid();
  SDV($modeSpec, "");
  SDV($olHighlight, "");
  return str_replace(
    array('$class', '$id', '$cm_id', '$modeSpec', '$opts', '$olOffset', '$olHighlight', '$txt'),
    array(@$opt['class'], $id, $cm_id, $modeSpec, $opts, IsEnabled($olOffset, 'null'), $olHighlight, PHSC($block)),
    $CodeMirrorBlockFmt);
}

if (!IsEnabled($EnableCodeMirrorPmWikiMarkup, 1)) return;

  SDV($CodeMirrorStylesFmt['codemirror-pmwiki-markup-block'], "
.cmblocktext.cm-pmwiki-markup {
  padding: 0;
  border: none;
}
.cmblocktext.cm-pmwiki-markup pre {
  color: black;
  background-color: #fafafa;
  padding: 0.5em;
}
");

Markup('markup', '<[=',
  "/\\(:markup(\\s+([^\n]*?))?:\\)[^\\S\n]*\\[([=@])(.*?)\\3\\]/si",
  "CodeMirrorMarkupMarkupMarkup");
Markup('markupend', '>markup',
  "/\\(:(markup)(\\s+([^\n]*?))?:\\)[^\\S\n]*\n(.*?)\\(:markupend:\\)/si",
  "CodeMirrorMarkupMarkupMarkup");
function CodeMirrorMarkupMarkupMarkup($m) {
  extract($GLOBALS['MarkupToHTML']); global $MarkupMarkupLevel;
  @$MarkupMarkupLevel++;
  $x = CodeMirrorMarkupMarkup($pagename, $m[4], $m[2]);
  $MarkupMarkupLevel--;
  return $x;
}

function CodeMirrorMarkupMarkup($pagename, $text, $opt = '') {
  global $CodeMirrorDirUrl, $CodeMirrorAddonsFmt,
    $MarkupWordwrapFunction, $MarkupWrapTag;

  SDV($CodeMirrorAddonsFmt['pmwiki'], "
<script type='text/javascript' src='$CodeMirrorDirUrl/pmwiki.js'></script>
<link rel='stylesheet' type='text/css' href='$CodeMirrorDirUrl/pmwiki.css' />
");
  // originally 'wordwrap'
  SDV($MarkupWordwrapFunction, 'IsEnabled');
  SDV($MarkupWrapTag, 'pre');
  $MarkupMarkupOpt = array('class' => 'vert');
  $opt = array_merge($MarkupMarkupOpt, ParseArgs($opt));
  $html = MarkupToHTML($pagename, $text, array('escape' => 0));
  if (@$opt['caption']) 
    $caption = str_replace("'", '&#039;', 
                           "<caption>{$opt['caption']}</caption>");
  $class = preg_replace('/[^-\\s\\w]+/', ' ', @$opt['class']);
  if (strpos($class, 'horiz') !== false) 
    { $sep = ''; $pretext = $MarkupWordwrapFunction($text, 40); } 
  else 
    { $sep = '</tr><tr>'; $pretext = $MarkupWordwrapFunction($text, 75); }
  $block = CodeMirrorBlock($pagename, 'pmwiki class=cm-pmwiki-markup', $pretext);
  return Keep(@"<table class='markup $class' align='center'>$caption
      <tr><td class='markup1' valign='top'><$MarkupWrapTag>$block</$MarkupWrapTag></td>$sep<td 
        class='markup2' valign='top'>$html</td></tr></table>");
}
