<?php if (!defined('PmWiki')) exit();

if (!($action == 'edit' || $action == 'comment')) return;

## Configurable settings
SDV($AuthorContribAuthor,
  '* [[{$Group}.{$Name}|{$Group}.{$Name}]]'
  .', in $CurrentTime ([[({$Group}.{$Name}?action=)diff]])');
SDV($AuthorContribOther,
  '* [[{$Group}.{$Name}]] '
  .' in $CurrentTime $[by] $AuthorLink ([[({$Group}.{$Name}?action=)diff]])');
SDV($AuthorContribAuthorPage, 'Contrib.$AuthorGroup/$1');
SDV($AuthorContribOtherPage, 'Contrib.Outer');

@include_once("scripts/author.php");

if (PageExists($AuthorPage)) {
  $RecentChangesFmt[$AuthorContribAuthorPage] = $AuthorContribAuthor;
} else {
  $RecentChangesFmt[$AuthorContribOtherPage] = $AuthorContribOther;
}
