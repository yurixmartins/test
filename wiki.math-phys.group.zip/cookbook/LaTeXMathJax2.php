
<?php if (!defined('PmWiki')) exit ();
/*
Copyright by Nicolas Poulain 2007.
Updated by Stefan Roettger / Matthias Hopf 2017.

You may use this code as you want, and change it as much as you want.

In order to use this recipe:

1.  Download and install
    1.1 the LaTeXMathJax.php file into your PmWiki's cookbook/ directory
    1.2 Optionally put a copy of MathJax/ into the pub/ directory
    1.3 You can get a copy of MathJax via
        git clone https://github.com/mathjax/MathJax.git MathJax

2.  Add the following line to a local customization file:
    include_once('cookbook/LaTeXMathJax.php');

That's it!  The script adds $$ ... $$ and $...$ markups that
display Mathml from LaTeX syntax, the first form centers the 
equation, while the second generates the equation "inline".

MathJax support by Matthias Hopf
- replaced the LaTeXMathML.js with the more modern MathJax.js script
- now supports all modern browsers and not just Mozilla

Updated for PHP 5.5 by Stefan Roettger
- backwards compatible
*/



SDV($RecipeInfo['Cookbook.LaTeXMathJax']['Version'], '20170325');

$HTMLHeaderFmt['jsMath'] = '
  <script type="text/x-mathjax-config">
    MathJax.Hub.Config({
                        tex2jax: { inlineMath: [["$","$"], ["\\\\(","\\\\)"]],
                                   displayMath: [["$$","$$"], ["\\\\[","\\\\]"]],
                                   ignoreClass: "fixed",
                                   processClass: "tex2jax",
                                 }});
  </script>
  <script type="text/x-mathjax-config"> 
    MathJax.Hub.Config({ 
        "HTML-CSS": { scale: 85, linebreaks: { automatic: true } }, 
        SVG: { linebreaks: { automatic:true } }, 
        displayAlign: "center" });
</script>
  <script type="text/javascript">
    var mathjax1 = document.createElement("script");
    var mathjax2 = document.createElement("script");
    mathjax1.type = "text/javascript";
    mathjax2.type = "text/javascript";
    mathjax1.onerror = function() {
      mathjax2.src = "https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML";
    }
    mathjax1.src = "$PubDirUrl/MathJax/MathJax.js?config=TeX-AMS-MML_HTMLorMML";
    document.head.appendChild(mathjax1);
    document.head.appendChild(mathjax2);
  </script>
  
';
// This line gives you LaTeX $$ $$ display equations in the center
// as it does with LaTeX.
Markup('$$', '<$',
  '/\\$\\$(.*?)\\$\$/',
  '<div class=displaymode>\\$ $1\\$</div>');

// This line gives you $ $ equations in line. You can then use
// \displaystyle as normal to get pretty print equations inline.
if(function_exists('Markup_e')) { # new format, no /e
Markup_e('$', 'directives',
  '/\\$(.*?)\\$/',
  "Keep('<span class=tex2jax>\$'.\$m[1].'\$</span>')");
}
else { # old format
Markup('$', 'directives',
  '/\\$(.*?)\\$/e',
  "Keep('<span class=tex2jax>\$'.PSS('$1').'\$</span>')");
}

?>
