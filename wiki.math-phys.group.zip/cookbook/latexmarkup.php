<?php if (!defined('PmWiki')) exit ();
# Simple inline Formatting


Markup('bib', 'inline', '/\\\bibitem\[(.*?)\]{(.*?)}{link:(.*?)}{arxiv:(.*?)}{pdf:(.*?)}{bib:(.*?)}/', '* [[#$1]] $2 ([[$3|link]][[$4|, arxiv]][[$5|, pdf]][[$6|, bib]])');


Markup('box', 'block', '/\\\begin{tcolorbox}(.*?)\\\end{tcolorbox}/', "<div class='round lrindent box' style='background-color: #dbdbdb; padding-left: 20px;'>$1</div>");

Markup('doi', 'directives', '/\[doi:(.*?)\]/', '[[https://doi.org/$1|@@doi:$1@@]]');

Markup('thm', 'block', '/\\\begin{theorem}(.*?)\\\end{theorem}/', '<b>Theorem.</b><em>$1</em>');
Markup('rem', 'block', '/\\\begin{remark}(.*?)\\\end{remark}/', '<b>Remark.</b><em>$1</em>');
Markup('def', 'block', '/\\\begin{definition}(.*?)\\\end{definition}/', '<b>Definition.</b> $1');
Markup('cor', 'block', '/\\\begin{corollary}(.*?)\\\end{corollary}/', '<b>Corollary.</b><em>$1</em>');
Markup('lem', 'block', '/\\\begin{lemma}(.*?)\\\end{lemma}/', '<b>Lemma.</b><em>$1</em>');
Markup('proof', 'block', '/\\\begin{proof}(.*?)\\\end{proof}/', '<em>proof.</em> $1 <span>&#9633;</span>');

Markup('emph', 'inline', '/\\\emph{(.*?)}/', '<em>$1</em>'); 
Markup('bf', 'inline', '/\\\textbf{(.*?)}/', '<b>$1</b>');
Markup('it', 'inline', '/\\\textit{(.*?)}/', '<i>$1</i>');

Markup('itemize', 'block', '/\\\begin{itemize}/', '<ul>');
Markup('itemend', 'block', '/\\\end{itemize}/', '</ul>');
Markup("enumerate", "block", "/\\\begin{enumerate}/", "<ol type='1'>");
Markup('enumend', 'block', '/\\\end{enumerate}/', '</ol>');
Markup('item', 'block', '/\\\item (.*?)/', '<li>$1</li>');

Markup('h1', 'block', '/\\\chapter{(.*?)}/', '<h1>$1</h1>');
Markup('h2', 'block', '/\\\section{(.*?)}/', '<h2>$1</h2>');
Markup('h3', 'block', '/\\\subsection{(.*?)}/', '<h3>$1</h3>');
Markup('h4', 'block', '/\\\paragraph{(.*?)}/', '<h4>$1</h4>');
Markup('h5', 'block', '/\\\subparagraph{(.*?)}/', '<h5>$1</h5>');

Markup('url', 'inline', '/\\\url{(.*?)}/', '<pre>$1</pre>');
Markup('href', 'inline', '/\\\href{(.*?)}{(.*?)}/', '[[$1|$2]]');
Markup('label', 'inline', '/\\\label{(.*?)}/', '[[#$1]]');
Markup('ref', 'inline', '/\\\ref{(.*?)}/', '[[$1|$1]]');


?>
