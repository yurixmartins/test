<?php   
$RecipeInfo['JavaScript-Editable']['Version'] = '20190619';
   Markup(
   'html',
   'fulltext',
   '/\\(:html:\\)(.*?)\\(:htmlend:\\)/msi',
   "MyHtml"
);
function MyHtml ($m) {
   return Keep(str_replace(array('&lt;', '&gt;', '&'), array('<', '>', '&'), $m[1]));
};
?>
