<?php include('pmwiki.php');
