/* CodeMirror - An enhanced page editor for PmWiki
 * Please refer to the main source module for copyright and license info.
 * Latest required version: 2017-03-22
 */
function setupCodeMirrorPosFix(pagename, editor) {
  'use strict';

  var previousLoadHandler = window.onload;
  window.onload = function () {
    if (previousLoadHandler) previousLoadHandler();

    if (!editor.codemirror) return;

    var cmItem = 'cm-pos-' + pagename,
        s = localStorage.getItem(cmItem);
    if (s) {
      var data = JSON.parse(s);
      editor.codemirror.scrollTo(data.scroll.left, data.scroll.top);
      editor.codemirror.setCursor(data.cursor);
      editor.codemirror.focus();
    };

    var form = document.querySelector('#wikitext form'),
        triggers = form.querySelectorAll('input[name=post], input[name=postedit], input[name=preview]');

    for (var i = 0; i < triggers.length; ++i) {
      var e = triggers[i];
      e.onclick = function () {
        var data = {
          scroll: editor.codemirror.getScrollInfo(),
          cursor: editor.codemirror.getCursor()
        };
        localStorage.setItem(cmItem, JSON.stringify(data));
        return true;
      };
    }
  };
}

