/* CodeMirror - An enhanced page editor for PmWiki
 * Please refer to the main source module for copyright and license info.
 * Latest required version: 2017-03-22
 */
function setupCodeMirrorResizer(container, editor, sizer) {
  'use strict';
  var enabled = false, startY, startHeight,
      initDrag = function (e) {
        startY = e.clientY;
        startHeight = parseInt(document.defaultView.getComputedStyle(container).height, 10);
        document.documentElement.addEventListener('mousemove', doDrag, false);
        document.documentElement.addEventListener('mouseup', stopDrag, false);
      },
      doDrag = function (e) {
        container.style.height = (startHeight + e.clientY - startY) + 'px';
        editor.codemirror.setSize(null, '100%');
      },
      stopDrag = function (e) {
        document.documentElement.removeEventListener('mousemove', doDrag, false);
        document.documentElement.removeEventListener('mouseup', stopDrag, false);
      };

  if (editor.codemirror) {
    var height = parseInt(document.defaultView.getComputedStyle(container).height, 10);
    editor.codemirror.setSize(null, height);
  }

  if (!enabled) {
    sizer.addEventListener('mousedown', initDrag, false);
    enabled = true;
  }
}

