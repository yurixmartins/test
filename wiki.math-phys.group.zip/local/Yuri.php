<?php
  $PageLogoUrl = 0;
  
  $Skin= "author-space";