<?php

function links($label,$link)
{Markup("$label", "_begin", "/\[$label\]/", "[[$link|$label]]");}

#Alphabetical order
##just add links("your label","corresponding link")

/* A */

links("abelian group","https://en.wikipedia.org/wiki/Abelian_group");
links("algebra","https://en.wikipedia.org/wiki/Algebra_over_a_field");
links("algebra-valued gauge theory","https://wiki.math-phys.group/Research/Algebra-ValuedGaugeTheories");
links("algebra-valued gauge theories","https://wiki.math-phys.group/Research/Algebra-ValuedGaugeTheories");
links("alternative algebra","https://ncatlab.org/nlab/show/alternative+algebra");
links("arity","https://ncatlab.org/nlab/show/arity+class");
links("associative algebra","https://ncatlab.org/nlab/show/associative+unital+algebra");
links("associator","https://ncatlab.org/nlab/show/associator");
links("axiomatic set theory","https://en.wikipedia.org/wiki/Set_theory#Formalized_set_theory");

/* B */

links("binary operation","https://en.wikipedia.org/wiki/Binary_operation");
links("braiding","https://ncatlab.org/nlab/show/braiding");

/* C */

links("cardinality","https://en.wikipedia.org/wiki/Cardinality");
links("cartesian closed category","https://ncatlab.org/nlab/show/cartesian+closed+category");
links("category","https://ncatlab.org/nlab/show/category");
links("category theory","https://ncatlab.org/nlab/show/category+theory");
links("Chern-Simons","https://ncatlab.org/nlab/show/Chern-Simons+theory");
links("classical field theory","https://en.wikipedia.org/wiki/Classical_field_theory");
links("classical field theories","https://en.wikipedia.org/wiki/Classical_field_theory");
links("Clifford algebra","https://ncatlab.org/nlab/show/Clifford+algebra");
links("commutative diagram","https://ncatlab.org/nlab/show/commutative+diagram");
links("compact","https://ncatlab.org/nlab/show/compact+space");
links("composition algebra","https://ncatlab.org/nlab/show/composition+algebra");

/* D */

links("differential cohomology","https://ncatlab.org/nlab/show/differential+cohomology");
links("divisibility","https://en.wikipedia.org/wiki/Divisibility_(ring_theory)");
links("division algebra","https://ncatlab.org/nlab/show/normed%20division%20algebra");
links("division ring","https://en.wikipedia.org/wiki/Division_ring");

/* E */

links("enveloping algebra","https://ncatlab.org/nlab/show/universal+enveloping+algebra");
links("Einstein-Hilbert-Palatini","https://en.wikipedia.org/wiki/Tetradic_Palatini_action");

/* F */

links("field","https://en.wikipedia.org/wiki/Field_(mathematics)");
links("finitary","https://en.wikipedia.org/wiki/Finitary");

/* G */

links("gauge theory","https://ncatlab.org/nlab/show/gauge+theory");
links("gauge theories","https://ncatlab.org/nlab/show/gauge+theory");
links("gravity","https://en.wikipedia.org/wiki/Gravity");
links("group","https://en.wikipedia.org/wiki/Group_(mathematics)");

/* H */

links("higher category","https://ncatlab.org/nlab/show/n-category");
links("higher category theory","https://ncatlab.org/nlab/show/higher+category+theory");
links("Hurwitz theorem","https://ncatlab.org/nlab/show/Hurwitz+theorem");

/* I */

links("ideal","https://en.wikipedia.org/wiki/Ideal_(ring_theory)");
links("infinitesimal symmetry","https://en.wikipedia.org/wiki/Infinitesimal_transformation");
links("infinitesimal symmetries","https://en.wikipedia.org/wiki/Infinitesimal_transformation");
links("instanton sector","https://ncatlab.org/nlab/show/instanton+sector");

/* J */

/* K */

/* L */

links("Leibniz algebra","https://ncatlab.org/nlab/show/Leibniz%20algebra");
links("Lie algebra","https://en.wikipedia.org/wiki/Lie_algebra");
links("Lie n-algebra","https://ncatlab.org/nlab/show/L-infinity-algebra");
links("Lie group","https://en.wikipedia.org/wiki/Lie_group");
links("Lie superalgebra","https://ncatlab.org/nlab/show/super+Lie+algebra");
links("Lie supergroup","https://ncatlab.org/nlab/show/supergroup");

/* M */

links("magma","https://en.wikipedia.org/wiki/Magma_(algebra)");
links("Malcev algebra","https://en.wikipedia.org/wiki/Malcev_algebra");
links("module","https://en.wikipedia.org/wiki/Module_(mathematics)");
links("monoid","https://en.wikipedia.org/wiki/Monoid");
links("monoidal category","https://ncatlab.org/nlab/show/monoidal+category");
links("monoid object","https://ncatlab.org/nlab/show/monoid+in+a+monoidal+category");
links("Moufang loop","https://ncatlab.org/nlab/show/Moufang+loop");

/* N */

links("n-category","https://ncatlab.org/nlab/show/n-category");
links("naive set theory","https://en.wikipedia.org/wiki/Naive_set_theory");
links("nonassociative algebra","https://ncatlab.org/nlab/show/nonassociative+algebra");
links("noncommutative algebra","https://en.wikipedia.org/wiki/Noncommutative_ring");
links("nonunital algebra","https://ncatlab.org/nlab/show/nonunital+algebra");
links("noncommutative geometry","https://ncatlab.org/nlab/show/noncommutative+geometry");
links("noncommutative spacetime","https://ncatlab.org/nlab/show/noncommutative+geometry");
links("noncommutative space-time","https://ncatlab.org/nlab/show/noncommutative+geometry");

/* O */

links("octonion","https://ncatlab.org/nlab/show/octonion");

/* P */

links("PI-algebra","https://en.wikipedia.org/wiki/Polynomial_identity_ring");
links("PI-ring","https://en.wikipedia.org/wiki/Polynomial_identity_ring");
links("properties","https://ncatlab.org/nlab/show/stuff%2C+structure%2C+property");
links("property","https://ncatlab.org/nlab/show/stuff%2C+structure%2C+property");
links("principal bundle","https://ncatlab.org/nlab/show/principal+bundle");
links("principal connection","https://ncatlab.org/nlab/show/connection+on+a+bundle");
links("principal \(G\)-connection","https://ncatlab.org/nlab/show/connection+on+a+bundle");

/* Q */

/* R */

links("ring","https://en.wikipedia.org/wiki/Binary_operation");

/* S */

links("semi-simple","https://en.wikipedia.org/wiki/Semi-simplicity");
links("set","https://en.wikipedia.org/wiki/Set_(mathematics)");
links("structure","https://ncatlab.org/nlab/show/stuff%2C+structure%2C+property");
links("stuff","https://ncatlab.org/nlab/show/stuff%2C+structure%2C+property");
links("supersymmetric gauge theory","https://en.wikipedia.org/wiki/Supersymmetric_gauge_theory");
links("super Lie group","https://ncatlab.org/nlab/show/supergroup");
links("super Lie algebra","https://ncatlab.org/nlab/show/super+Lie+algebra");
links("super-Lie algebra","https://ncatlab.org/nlab/show/super+Lie+algebra");
links("super-Lie group","https://ncatlab.org/nlab/show/supergroup");

/* T */

/* U */

links("unary operation","https://en.wikipedia.org/wiki/Unary_operation");
links("unitor","https://ncatlab.org/nlab/show/unitor");
links("universal algebra","https://en.wikipedia.org/wiki/Universal_algebra");

/* V */

links("variety of algebra","https://ncatlab.org/nlab/show/variety+of+algebras");
links("vector space","https://en.wikipedia.org/wiki/Vector_space");

/* W */
/* X */

/* Y */

links("Yang-Mills","https://ncatlab.org/nlab/show/Yang-Mills+theory");

/* Z */

links("ZFC","https://en.wikipedia.org/wiki/Zermelo%E2%80%93Fraenkel_set_theory");

?>