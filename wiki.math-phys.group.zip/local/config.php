<?php if (!defined('PmWiki')) exit();

#add a sitemap
include_once("cookbook/sitemap.php");


#anti-spam/anti-boot
##email protector
include_once("cookbook/deobmail.php");
##page size changes
function PageTextSize($pagename, $page, $new) {
  global $EnablePost, $IsBlocked, $WhyBlockedFmt, $MessagesFmt;
  if (!$EnablePost) return;
  $L1 = strlen($new['text']);
  $L0 = strlen($page['text']);
  if(!$L0) return; # page is new or was empty
  if ( $L1/$L0 < .5 && $L0-$L1>200) { # more than half AND more than 200 characters removed
    $EnablePost = 0;
    $IsBlocked = 1;
    $WhyBlockedFmt[] = $MessagesFmt[] = '
    <p style="color:red">You tried to remove a large part of the page content.</p>
    ';
  }
}
## to enable it on all pages, remove the # before the next line
 array_unshift($EditFunctions, 'PageTextSize');

##enable captchaa
#$EnablePostCaptchaRequired = 1;
include_once("cookbook/captcha.php");

$EnableCaptchaImage=0;

##add SSL
if (@$_SERVER['HTTPS'] != 'on' && @$_SERVER['SERVER_PORT'] != '443') {
  header( "Location: " . "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] );
  exit('<html><body>
    <a href="https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . '">Please use TLS.</a>
    </body></html>');
}

$ScriptUrl = "https://".$_SERVER['HTTP_HOST']."";
$PubDirUrl = 'https://'.$_SERVER['HTTP_HOST'].'/pub';

##  $WikiTitle is the name that appears in the browser's title bar.
$WikiTitle = 'Math-Phys-Cat Wiki';

$EnablePathInfo = 1;

## simplify the editing pages
function clearframe($pagename,$args) {
        $GLOBALS['PageHeaderFmt'] = '';
        $GLOBALS['PageFooterFmt'] = '';
        $GLOBALS['PageTitleFmt'] = '';
        $GLOBALS['PageLeftFmt'] = '';
      }
      $HandleEditFmt = array(
        'function:clearframe',
        &$PageStartFmt,
        &$PageEditFmt,
        'wiki:$[PmWiki.EditQuickReference]',
        &$PagePreviewFmt,
        &$PageEndFmt);
        
## Skin
$EnableAutoSkinList = 1;
include_once('cookbook/skinchange.php');
$Skin = 'pmwiki-responsive';

##backup with ?action=backup
include_once('cookbook/backup.php');

##customize editing page (add custom fields)
#forcing to add a title:
include_once("cookbook/edittitle.php");
$ForceTitle = 1;
#forcing to add a description:
include_once("cookbook/editdescription.php");
$ForceDescription = 1;

##allow open search
include_once("cookbook/opensearch.php");
$OpenSearchUrl="$ScriptUrl/Wiki/Search";
$OpenSearchData= array( 'ShortName' => substr( $WikiTitle, 0, 16 ), 'Description' => "Search $WikiTitle");

#compare different versions of a page
$ViewDiffCompare = 0;
$EnableDiffInline = 0;
$DiffStartFmt = "<div><div>
  <div>
  <ul><li>\$DiffTime 
  \$[by] <a href='https://wiki.math-phys.group/Authors/\$DiffAuthor'>\$DiffAuthor</a> (<a href='{\$PageUrl}?action=viewdiff&amp;time=\$DiffGMT'>View</a>, \$DiffRestoreFmt)</ul></div>";
$DiffRestoreFmt="<a href='{\$PageUrl}?action=edit&amp;restore=\$DiffId&amp;preview=y'>$[Restore]</a>";
include_once("cookbook/viewdiff.php");

##disallow to search read-blocked pages
$EnablePageListProtect=1;

##remove messages "results from..."
$SearchResultsFmt = '$MatchList';

##redirect without "redirected from..."
$EnableRedirectQuiet=1;

##changing the authors profile group 
$AuthorGroup='Authors';

##customize recent changes pages
#defining variables 
$pagename = ResolvePageName($pagename);
$group = PageVar($pagename, '$Group');
$name = PageVar($pagename, '$Name');
#excluding certain groups
if ($group == 'Site')
  unset ($RecentChangesFmt['SiteGroup.AllRecentChanges']);
if ($group == 'SiteAdmin')
unset ($RecentChangesFmt['SiteGroup.AllRecentChanges']);
if ($name == 'Template')
  unset ($RecentChangesFmt['$SiteGroup.AllRecentChanges']);
#changing the display  
  $RecentChangesFmt = array(
  '$SiteGroup.AllRecentChanges' =>
    '* [[{$Group}.{$Name} | {$Group}.{$NameSpaced}]]  - edited $CurrentTime $[by] $AuthorLink',
  '$Group.RecentChanges' =>
    '* [[{$Group}/{$Name} | {$Group}.{$NameSpaced}]]  - edited $CurrentTime $[by] $AuthorLink');

#show/hide section content
$ToggleNextSelector = 'div.hide, p.hide, dl.hide dt';
#other option
$HTMLStylesFmt['untoggle'] = '.clicker { color:#0645AD; cursor:pointer; }';
$WikiStyle['h'] = array('apply' => 'item', 'class' => 'h');
$HTMLFooterFmt['untoggle'] = '<script type="text/javascript" 
   src="$FarmPubDirUrl/untoggle.js"></script>';

## include table of contents
include_once("cookbook/pagetoc.php");

## pagelists multitarget
$EnablePLMTLink = 1;
include_once("cookbook/pagelistmultitargets.php");

##autolinks
include_once("links.php");

#some wikistyles (e.g, color boxes)
include_once('cookbook/wsplus.php'); 
$WikiStyleCSS[] = 'line-height';

## simplify the creation of tags
$TaggerGroups['tags'] = 'Category';
include_once("cookbook/tagger.php");

## add box which creates pages in a specific group
include_once("cookbook/newpagebox3.php");


##immediately creating pages for categories
$AutoCreate['/^Category\./'] = array('ctime' => $Now, 'title' => $Name, 'text' => 'The following are pages in the category "{$Name}", organized by page types.(:pagelist link=Category.{$Name} list=normal:)');

## allow javascripts
include_once('cookbook/JavaScript-Editable.php');

##templates and default pages
$LinkPageSelfFmt = "<span class='selflink'>\$LinkText</span>"; 
$DefaultPage = 'Wiki.About';
$EditTemplatesFmt = 'Site.Template'; 
$EditTemplatesFmt = '{$Group}.Template';

# Provide action conditional (:if action ACTION:)
$Conditions['action'] = '\$GLOBALS["action"]==\$condparm';
$HandleAuth['diff'] = 'edit';

#limit diffs
  if ($action=='diff') {
    $DiffCountPerPage = 20; # Optional
    include_once("cookbook/limitdiffsperpage2.php");
    } 

#Add ?action=delete
include_once('cookbook/deletepage.php');
$HandleAuth['delete'] = 'admin';

#require author of an edition
$EnablePostAuthorRequired = 1;
#create page with contributions of authors
if ($action == 'edit' || $action == 'comment') {
include_once("cookbook/authorcontrib.php"); }

# add cauthor to page attributes as extra field for ?action=attr
$PageAttributes['cauthor'] = '$[Page created by:]';
# add page variable {$CreatedBy} 
$FmtPV['$CreatedBy'] = '@$page["cauthor"]';
# automatically set page creator to $Author for every new page
function SetPageCreator($pagename, &$page, &$new) {
	global $EnablePost, $Author, $PageCreator, $Now;
	SDV($PageCreator, $Author);
	if ($EnablePost && !$new["author"])
		$new["cauthor"] = $PageCreator; 
}
array_unshift($EditFunctions, 'SetPageCreator');

## Passwords
$DefaultPasswords['admin'] = pmcrypt('TYVi8SLv8CWzft*0');
#$DefaultPasswords['edit'] = pmcrypt('cafe4andar');
$HandleAuth['delete'] = 'admin';

##allow comments
include_once("cookbook/commentboxplus.php");

## Logos
#$PageLogoUrl = "$PubDirUrl/skins/pmwiki-responsive/math-phys-cat-wiki-header.png";
$FavIcon = "$PubDirUrl/skins/pmwiki-responsive/math-phys-wiki.ico";

##Automatic break line
$HTMLPNewline = '<br/>';

# break page lists
include_once("cookbook/breakpagelist.php");
$FPLTemplateFunctions['FPLBreakPageList'] = 350;

#button with options
#include_once('cookbook/fploptionmenu.php');
include_once('cookbook/jumpbox.php');

## Unicode (UTF-8) allows the display of all languages and all alphabets.
## Highly recommended for new wikis.
include_once("scripts/xlpage-utf-8.php");
XLPage('en','PmWikiEn.XLPage');

## Activate the RenamePage recipe.
if ($action == 'rename' || $action == 'postrename' || $action == 'links' ) {
  include_once("cookbook/renamehelper.php");
  include_once("cookbook/rename.php");
}

## MATH
#latex
include_once('cookbook/latexmarkup.php');
include_once('cookbook/LaTeXMathJax.php');
##Uploads
$UploadMaxSize = 1000000;
$EnableUpload = 1;
$DefaultPasswords['upload'] = pmcrypt('cafe4andar');

##allow ?action=markdown
include_once("cookbook/markdown-output/markdown-output.php");

##Footnote
include_once("cookbook/footnote2.php");

$EnableEditAutoText = 1;

## GUI Buttons
#enable
$EnableGUIButtons = 1;

#buttons
 SDV($GUIButtons['upload'], array(220, '', '', '',
    "<a href='\$PageUrl?action=upload' target='_blank'><img src='https://wiki.math-phys.group/pub/guiedit/attach.gif' alt='Upload a file'></a>", ''));
     SDV($GUIButtons['space-help'], array(99998, '', '', '',
    "<img src='https://wiki.math-phys.group/pub/guiedit/space1.gif' alt='   '>", ''));
     SDV($GUIButtons['help'], array(99999, '', '', '',
    "<a href='https://wiki.math-phys.group/Wiki/HowToEdit' target='_blank'><img src='' alt='help!'></a>", ''));
    SDV($GUIButtons['space-tags'], array(999998, '', '', '',
    "<img src='https://wiki.math-phys.group/pub/guiedit/space1.gif' alt='   '>", ''));
     SDV($GUIButtons['tags'], array(999999, '', '', '',
    "<a href='https://wiki.math-phys.group/Wiki/Categories' target='_blank'><img src='' alt='tags'></a>", ''));
    SDV($GUIButtons['space-uploads'], array(9999998, '', '', '',
    "<img src='https://wiki.math-phys.group/pub/guiedit/space1.gif' alt='   '>", ''));
    SDV($GUIButtons['uploads'], array(9999999, '', '', '',
    "<a href='https://wiki.math-phys.group/uploads' target='_blank'><img src='' alt='uploads'></a>", ''));
    
    SDV($GUIButtons['space-links'], array(99999998, '', '', '',
    "<img src='https://wiki.math-phys.group/pub/guiedit/space1.gif' alt='   '>",''));
    
    SDV($GUIButtons['links'], array(99999999, '', '', '',
    "<a href='https://wiki.math-phys.group/Wiki/Links' target='_blank'><img src='' alt='links'></a>", ''));
    
    
 $GUIButtons ['tikz']     = array(900, '\\n (:html:) \\n<script type =text/tikz\\>\\n \\\begin{tikzpicture} \\n', '\\n \\\end{tikzpicture} \\n</script> \\n(:htmlend:)\\n \\n', '$[...diagram code...]', '$GUIButtonDirUrlFmt/tikz.gif"$[Tikz diagram]"');
  $GUIButtons ['thm']     = array(800, '||border=0 width=90% \\n|**Theorem**. //', '//| \\n', '$[...statement...]',  '$GUIButtonDirUrlFmt/thm.gif"$[Theorem environment]"');
  $GUIButtons ['proof']     = array(801, '\\n //proof.// ', '&#8718; \\n', '$[...proof steps...]',  '$GUIButtonDirUrlFmt/proof.gif"$[Proof environment]"');
   $GUIButtons ['html']     = array(902, '\\n(:html:)\\n', '(:htmlend:)', '$[...html code...]',  '$GUIButtonDirUrlFmt/html.gif"$[Html markup]"');
   $GUIButtons ['box']     = array(903, '\\n>>box bgcolor=#dbdbdb padding-left=20px<<\\n', '\\n>><<', '$[...box content...]',  '$GUIButtonDirUrlFmt/box.gif"$[box markup]"');
   $GUIButtons ['person']     = array(904, '\\n[[People/FullName|Full Name]]\\n', '\\n', '(:include People.FullName#from#to:)',  '$GUIButtonDirUrlFmt/person.png"$[person markup]"');
$GUIButtons ['slide']     = array(114, '\\n %%%%', '\\n','', '$GUIButtonDirUrlFmt/page_break.png"$[page break/new slide]"');
   
      $GUIButtons ['toggle']     = array(104, '>>hide<< \\n', ' \\n>>a<< \\n $[...show/hide content...] \\n>><<', '$[...title...]',  '$GUIButtonDirUrlFmt/toggle.png"$[show/hide content]"');
 
 #  $GUIButtons['tab'] = array(120, "\t", '', '', '$GUIButtonDirUrlFmt/tab.png"$[Tab]"');
  $GUIButtons ['pagetoc'] = array(110, '\\n(:toc:)\\n', '', '',
     '$GUIButtonDirUrlFmt/toc.gif"[Table of content]"');		
    $GUIButtons['em']  = array(100, "//", "//", '$[Emphasized]',
                  '$GUIButtonDirUrlFmt/em.gif"$[Emphasized (italic)]"',
                  '$[ak_em]');
  $GUIButtons['strong']   = array(101, "**", "**", '$[Strong]',
                  '$GUIButtonDirUrlFmt/strong.gif"$[Strong (bold)]"',
                  '$[ak_strong]');
  $GUIButtons ['underline'] = array(95, '{+', '+}', '$[text]',
   '$GUIButtonDirUrlFmt/underline.gif"$[Underline]"'); 
$GUIButtons['h1'] = array(111, '\\n! ', '\\n', '$[Heading]', '$GUIButtonDirUrlFmt/h1.gif"$[Ordered Section]"');
$GUIButtons['h2'] = array(112, '\\n!! ', '\\n', '$[Subheading]',
                     '$GUIButtonDirUrlFmt/h2.gif"$[Ordered Subsection]"');
#$GUIButtons['h3'] = array(113, '\\n!!! ', '\\n', '$[Subsubheading]',
  #                   '$GUIButtonDirUrlFmt/h3.gif"$[Ordered Subsubsection]"');
 $GUIButtons['indent'] = array(119, '\\n->', '\\n', '$[Indented text]',
                     '$GUIButtonDirUrlFmt/indent.gif"$[Indented text]"');
 $GUIButtons['outdent'] = array(118, '\\n-<', '\\n', '$[Hanging indent]',
                     '$GUIButtonDirUrlFmt/outdent.gif"$[Hanging indent]"');
 $GUIButtons['ol'] = array(117, '\\n# ', '\\n', '$[Ordered list]',
                     '$GUIButtonDirUrlFmt/ol.gif"$[Ordered (numbered) list]"');
 $GUIButtons['ul'] = array(116, '\\n* ', '\\n', '$[Unordered list]',
                     '$GUIButtonDirUrlFmt/ul.gif"$[Unordered (bullet) list]"');
 $GUIButtons['table'] = array(600,
                       '||border=1 style=border-collapse:collapse width=90%\\n|!Hdr |!Hdr |!Hdr |\\n|     |     |     |\\n|     |     |     |\\n', '', '',
                     '$GUIButtonDirUrlFmt/table.gif"$[Table]"');
                  
#add highlight edition CODE MIRROR
$CodeMirrorActivePresets['linenumbers'] = 0;
#$CodeMirrorActivePresets['fullscreen'] = 0;
$CodeMirrorActivePresets['autoresize'] = 1;
#$CodeMirrorActivePresets['maxheight'] = 0;
#$CodeMirrorPresetParams['maxheight'] = '10em';
#$CodeMirrorPresetParams['font-size'] = '10px';
#$CodeMirrorActivePresets['search'] = 1;
#$CodeMirrorActivePresets['resizer'] = 1;
#$CodeMirrorActivePresets['syntax'] = 1;
#$CodeMirrorActivePresets['fullscreen-esc'] = 0;
include_once("cookbook/codemirror.php");

#editmore
$EMFields = array('tags'); 
include_once("cookbook/editmore.php");

#enable ?action=trash
include_once("cookbook/trash.php");

#auto save
#$EnableDrafts = 1; 
#include_once("cookbook/autosave.php");

## Additional Markups
#Creole
include_once("scripts/creole.php");


#use "" instead of """"
if ($action != 'edit') {
 # make curly quotes 
 Markup("\"",'_end',"/\"(.*?)\"/",'&#8220;$1&#8221;');
 # make m-dash 
 Markup("---",'_end',"/---([^-])/",'&#8212;$1');
 # make n-dash 
 Markup("--",'_end',"/--([^->])/",'&#8211;$1'); 
 # curly single quote in contraction
 Markup("a'a",'_end',"/([A-Za-z])'([A-Za-z][A-Za-z]?[^A-Za-z])/",'$1&rsquo;$2');
}

# ["blockquote"]
Markup("bq",">[=","/(\n[^\\S\n]*)?\\[([\"])(.*?)\\2\\]/s","$1<blockquote>$3</blockquote>");
# fdsfsd

# > blockquote (email type)
Markup('>','>> ','/^&gt;$/',"<:block,1><blockquote class=\"email qlv0\"></blockquote>");
Markup('> ','block','/^((&gt;)+) (.*)$/',"EmailBlockquote");
function EmailBlockquote ($m) {
	$cnt = strlen($m[1])/4; if ($cnt>3) $cnt = 3;
	return "<:block,1><blockquote class=\"email qlv".$cnt."\">".$m[3]."</blockquote>";
}